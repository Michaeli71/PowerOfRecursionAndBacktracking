package part1.recursion_intro;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import part1.recursion_intro.ReverseString;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class ReverseStringTest
{
	@ParameterizedTest(name = "reverseString({0}) => {1}")
	@CsvSource({ "A, A", "ABC, CBA", "abcdefghi, ihgfedcba" })
	public void reverseString(String input, String expected) {
		String result = ReverseString.reverseString(input);

		assertEquals(expected, result);
	}

	@ParameterizedTest(name = "reverseStringShort({0}) => {1}")
	@CsvSource({ "A, A", "ABC, CBA", "abcdefghi, ihgfedcba" })
	public void reverseStringShort(String input, String expected) {
		String result = ReverseString.reverseStringShort(input);

		assertEquals(expected, result);
	}
}
