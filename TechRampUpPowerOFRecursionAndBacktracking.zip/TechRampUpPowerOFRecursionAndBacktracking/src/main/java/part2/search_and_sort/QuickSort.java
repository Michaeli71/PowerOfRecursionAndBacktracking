package part2.search_and_sort;

public class QuickSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
