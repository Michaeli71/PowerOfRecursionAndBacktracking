package part2.search_and_sort.exercises;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex1_BinarySearch
{
    private Ex1_BinarySearch()
    {
    }

    public static boolean binarySearch(final int[] sortedValues, final int searchValue)
    {
        // TODO
    	return false;
    }

    public static boolean binarySearchOptimized(final int[] values, final int searchValue)
    {
    	// TODO
    	return false;
    }

   

    static int binarySearchOptimizedWithPos(final int[] values, final int searchValue)
    {
        return binarySearchOptimizedWithPos(values, searchValue, 0, values.length - 1);
    }

    static int binarySearchOptimizedWithPos(final int[] values,
                                            final int searchValue,
                                            final int left, final int right)
    {
        if (right >= left)
        {
            final int midIdx = (left + right)/2;

            if (searchValue == values[midIdx])
                return midIdx;

            if (searchValue < values[midIdx])
                return binarySearchOptimizedWithPos(values, searchValue, left, midIdx - 1);
            else
                return binarySearchOptimizedWithPos(values, searchValue, midIdx + 1, right);
        }

        return -1;
    }
}
