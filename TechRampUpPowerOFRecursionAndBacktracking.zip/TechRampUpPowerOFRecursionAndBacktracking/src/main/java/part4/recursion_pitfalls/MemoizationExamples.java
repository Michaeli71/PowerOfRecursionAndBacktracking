package part4.recursion_pitfalls;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class MemoizationExamples
{
    private MemoizationExamples()
    {
    }

    public static void main(final String[] args)
    {
        final long start = System.currentTimeMillis();
        final long result = fibRec(47);
        final long end = System.currentTimeMillis();
        System.out.println("fibRec(47)=" + result);
        System.out.println("took " + (end-start) + " ms");

        final long start2 = System.currentTimeMillis();
        final long result2 = fibonacciOptimized(47);
        System.out.println("fibonacciOpt(47)=" + result2);
        final long end2 = System.currentTimeMillis();
        System.out.println("took " + (end2-start2) + " ms");

        final long start2b = System.currentTimeMillis();
        final long result2b = fibonacciOptimizedNicer(47);
        System.out.println("fibonacciOptimizedNicer(47)=" + result2b);
        final long end2b = System.currentTimeMillis();
        System.out.println("took " + (end2b-start2b) + " ms");
    }


    public static long fibRec(final int n)
    {
        if (n <= 0)
            throw new IllegalArgumentException("n must be >= 1");

        // rekursiver Abbruch
        if (n == 1 || n == 2)
            return 1;

        // rekursiver Abstieg
        return fibRec(n - 1) + fibRec(n - 2);
    }

	static long fibonacciOptimized(final int n)
	{
	    return fibonacciMemo(n, new HashMap<>());
	}
	
	static long fibonacciMemo(final int n,
	                          final Map<Integer, Long> lookupMap)
	{
	    if (n <= 0)
	        throw new IllegalArgumentException("must be > 0");
	
	    // MEMOIZATION: prüfe, ob vorberechnetes Ergebnis
	    if (lookupMap.containsKey(n))
	    {
	        return lookupMap.get(n);
	    }
	
	    // normaler Algorithmus mit Hilfsvariable für Resultat
	    long result = 0;
	    if (n == 1)
	        result = 1;
	    else if (n == 2)
	        result = 1;
	    else
	        result = fibonacciMemo(n - 1, lookupMap) +
	                 fibonacciMemo(n - 2, lookupMap);
	
	    // MEMOIZATION: speichere berechnetes Ergebnis
	    lookupMap.put(n, result);
	
	    return result;
	}

	static long fibonacciOptimizedNicer(final int n)
	{
	    return fibonacciMemoOpt(n, new HashMap<>(Map.of(1, 1L, 2, 1L)));
	}
	
	static long fibonacciMemoOpt(final int n,
	                             final Map<Integer, Long> lookupMap)
	{
	    if (n <= 0)
	        throw new IllegalArgumentException("must be > 0");
	
	    // MEMOIZATION: prüfe, ob vorberechnetes Ergebnis
	    if (lookupMap.containsKey(n))
	        return lookupMap.get(n);
	
	    // normaler Algorithmus mit Hilfsvariable für Resultat
	    long result = fibonacciMemoOpt(n - 1, lookupMap) + fibonacciMemoOpt(n - 2, lookupMap);
	
	    // MEMOIZATION: speichere berechnetes Ergebnis
	    lookupMap.put(n, result);
	
	    return result;
	}
}
