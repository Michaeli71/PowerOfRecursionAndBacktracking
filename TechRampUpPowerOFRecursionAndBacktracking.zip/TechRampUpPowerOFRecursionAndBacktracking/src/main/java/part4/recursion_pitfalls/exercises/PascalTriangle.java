package part4.recursion_pitfalls.exercises;

/**
 * Beispielprogramm f�r das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class PascalTriangle {

    public static int pascalRec(final int row, final int col)
    {
        // rekursiver Abbruch: Spitze
        if (col == 1 && row == 1)
            return 1;

        // rekursiver Abbruch: R�nder
        if (col == 1 || col == row)
            return 1;

        // rekursiver Abstieg
        return pascalRec(row - 1, col) + pascalRec(row - 1, col - 1);
    }

    public static void main(String[] args) {
        final long start3 = System.currentTimeMillis();
        final long result3 = pascalRec(42, 15);
        System.out.println("calcPascal(42, 15)=" + result3);
        final long end3 = System.currentTimeMillis();
        System.out.println("took " + (end3-start3) + " ms");
    }
}
