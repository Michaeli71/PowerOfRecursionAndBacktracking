package part4.recursion_pitfalls;

import java.math.BigInteger;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Fibonacci
{
    private Fibonacci()
    {
    }

	public static void main(String[] args) 
	{
		System.out.println("fibRec(42) = " + fibRec(42)); // sofort
		System.out.println("fibRec(45) = " + fibRec(45)); // ca. 3 s
		System.out.println("fibRec(50) = " + fibRec(50)); // ca. 23 s
		System.out.println("fibRec(70) = " + fibRec(70)); // take a break ...
		
		System.out.println("fibBigInt(50) = " + fibBigInt(50)); //  
		System.out.println("fibBigInt(100) = " + fibBigInt(100)); // fibBigInt
	}
    
	static long fibRec(final int n)
	{
	    if (n <= 0)
	        throw new IllegalArgumentException("must be positive and >= 1");
	
	    // rekursiver Abbruch
	    if (n == 1 || n == 2)
	        return 1;
	
	    // rekursiver Abstieg
	    return fibRec(n - 1) + fibRec(n - 2);
	}

    static long fibIterative(final int n)
    {
        if (n <= 0)
            throw new IllegalArgumentException("must be >= 1");

        if (n == 1 || n == 2)
            return 1;

        long fibN_2 = 1;
        long fibN_1 = 1;

        for (int count = 2; count < n; count++)
        {
            final long fibN = fibN_1 + fibN_2;

            fibN_2 = fibN_1;
            fibN_1 = fibN;
        }

        return fibN_1;
    }

    static BigInteger fibBigInt(int n)
    {
        if (n <= 0)
            throw new IllegalArgumentException("must be >= 1");

        if (n == 1 || n == 2)
            return BigInteger.ONE;

        BigInteger fibN_2 = BigInteger.ONE;
        BigInteger fibN_1 = BigInteger.ONE;

        int count = 2;
        while (count < n)
        {
            final BigInteger fibN = fibN_1.add(fibN_2);

            fibN_2 = fibN_1;
            fibN_1 = fibN;

            count++;
        }

        return fibN_1;
    }
}
