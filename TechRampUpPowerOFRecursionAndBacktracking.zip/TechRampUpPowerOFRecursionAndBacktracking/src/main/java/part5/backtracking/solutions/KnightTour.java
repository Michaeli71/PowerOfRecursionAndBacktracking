package part5.backtracking.solutions;

class KnightTour
{
    static int UNVISITED = -1;

    enum KnightDirection {

        // Es kommt auf die Reihenfolge an!!
        RIGHT_DOWN_1(2, 1),RIGHT_DOWN_2(1, 2),  LEFT_DOWN_1(-2, 1), LEFT_DOWN_2(-1,
                                                                                2),
        RIGHT_UP_1(2, -1), RIGHT_UP_2(1, -2), LEFT_UP_1(-2, -1), LEFT_UP_2(-1, -2);

        // Duration: 7583 ms, 0,0
        /*
        RIGHT_DOWN_1(2, 1), RIGHT_DOWN_2(1, 2), LEFT_DOWN_2(-1, 2), LEFT_DOWN_1(-2, 1),
        RIGHT_UP_1(2, -1), RIGHT_UP_2(1, -2),  LEFT_UP_1(-2, -1), LEFT_UP_2(-1, -2);
        */

        // Duration: 15s, 0,0
        /*
        RIGHT_DOWN_1(2, 1), RIGHT_DOWN_2(1, 2), LEFT_DOWN_2(-1, 2), LEFT_DOWN_1(-2, 1),
        RIGHT_UP_1(2, -1), RIGHT_UP_2(1, -2),  LEFT_UP_2(-1, -2), LEFT_UP_1(-2, -1);
         */

        final int dx;

        final int dy;

        KnightDirection(final int dx, final int dy)
        {
            this.dx = dx;
            this.dy = dy;
        }
    }

    public static void main(final String args[])
    {
        System.out.println("Start solving ...");
        final long start = System.currentTimeMillis();
        solveKnightTour(6, 0, 0);
        final long end = System.currentTimeMillis();
        System.out.println("Solving took ..." + (end-start) + " ms");


        System.out.println("Start solving ...");
        final long start2 = System.currentTimeMillis();
        solveKnightTour(8, 2, 2);
        final long end2 = System.currentTimeMillis();
        System.out.println("Solving took ..." + (end2-start2) + " ms");
    }

    static boolean solveKnightTour(final int size, final int startX, final int startY)
    {
        final int[][] board = createBoard(size);

        board[startX][startY] = 0;
        printBoard(board);

        /* Start from 0,0 (or startX, startY) and explore all tours using */
        if (solveKnightTour(startX, startY, 1, board))
        {
            printBoard(board);
            return true;
        }

        System.out.println("No solution");
        return false;
    }

    /* A recursive utility function to solve Knight
       Tour problem */
    static boolean solveKnightTour(final int x, final int y, final int moveCount, final int board[][])
    {
        if (moveCount == board.length * board[0].length)
            return true;

        // Try all next moves from the current coordinate
        for (final KnightDirection dir : KnightDirection.values())
        {
            final int next_x = x + dir.dx;
            final int next_y = y + dir.dy;

            if (isOnBoard(next_x, next_y, board) && isNotVisited(next_x, next_y, board))
            {
                board[next_y][next_x] = moveCount;
                //printBoard(board);
                //System.out.println("--------------------------");
                //System.out.println("moveCount: " + (moveCount + 1));

                if (solveKnightTour(next_x, next_y, moveCount + 1, board))
                    return true;
                else
                    board[next_y][next_x] = UNVISITED; // backtracking
            }
        }

        return false;
    }

    static boolean isSafe(final int x, final int y, final int sol[][])
    {
        return x >= 0 && x < sol[0].length && y >= 0 && y < sol.length && sol[y][x] == UNVISITED;
    }

    static int[][] createBoard(final int size)
    {
        final int board[][] = new int[size][size];

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                board[y][x] = UNVISITED;
            }
        }
        return board;
    }

    static void printBoard(final int[][] board)
    {
        for (int y = 0; y < board.length; y++)
        {
            for (int x = 0; x < board[0].length; x++)
            {
                System.out.format("%2d ", board[y][x]);
            }

            System.out.println();
        }
    }

    static boolean isOnBoard(final int x, final int y, final int board[][])
    {
        return x >= 0 && x < board[0].length && y >= 0 && y < board.length;
    }

    static boolean isNotVisited(final int x, final int y, final int board[][])
    {
        return board[y][x] == UNVISITED;
    }
}
