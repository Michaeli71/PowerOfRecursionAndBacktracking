package part3.twodim;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class FloodFillExample
{
	private FloodFillExample()
	{
	}

	static void floodFill(final char[][] values, final int x, final int y) {
		if (x < 0 || y < 0)
			return;

		if (y >= values.length || x >= values[y].length)
			return;

		if (values[y][x] == ' ') {
			values[y][x] = '*';

			// fill in all 4 dirs
			floodFill(values, x, y - 1);
			floodFill(values, x + 1, y);
			floodFill(values, x, y + 1);
			floodFill(values, x - 1, y);
		}
	}
}
