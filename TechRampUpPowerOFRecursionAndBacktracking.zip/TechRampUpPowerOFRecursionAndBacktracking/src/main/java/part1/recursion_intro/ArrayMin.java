package part1.recursion_intro;

import java.util.List;

public class ArrayMin {

	public static void main(String[] args) {
		System.out.println(min(new int[] { 2, 7, 5, 4, 11 }));
		System.out.println(min(new int[] { 7, 2, 7, 5, 4, 11 }));
		System.out.println(min(new int[] { 23, 11, 20, 1 }));

		System.out.println(min(List.of(23, 11, 20, 1)));
		System.out.println(max(List.of(23, 11, 20, 1)));
	}

	static int min(final int[] values) {
		return min(values, 0, Integer.MAX_VALUE);
	}

	static int min(final int[] values, final int pos, int currentMin) {
		if (pos >= values.length)
			return currentMin;

		final int current = values[pos];
		if (current < currentMin)
			currentMin = current;

		return min(values, pos + 1, currentMin);
	}

	static int min(final List<Integer> values) {
		return min(values, Integer.MAX_VALUE);
	}

	static int min(final List<Integer> values, int currentMin) {
		if (values.size() == 0)
			return currentMin;

		final int current = values.get(0);
		if (current < currentMin)
			currentMin = current;

		return min(values.subList(1, values.size()), currentMin);
	}

	static int max(final List<Integer> values) 
	{
		return max(values, Integer.MIN_VALUE);
	}
	
	static int max(final List<Integer> values, int currentMax) 
	{
		if (values.size() == 0)
			return currentMax;
	
		final int current = values.get(0);
		if (current > currentMax)
			currentMax = current;
	
		return max(values.subList(1, values.size()), currentMax);
	}
}
