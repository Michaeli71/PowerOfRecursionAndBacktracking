package part1.recursion_intro.exercises;

import java.util.List;

public class Ex5_Bonus_MinAndMax {

	public static void main(String[] args) {

		System.out.println(calcMinAndMax(List.of(2, 3, 5, 7, 11, 1, 2, 13)));
		System.out.println(calcMinAndMax(List.of(23, 11, 7, 2, 14, 7)));
		System.out.println(calcMinAndMax(List.of(71, 79, 20)));
	}

	record MinAndMaxValue(int min, int max) {
	}

	static MinAndMaxValue calcMinAndMax(List<Integer> values) {
		return new MinAndMaxValue(0, 0);
	}
}
