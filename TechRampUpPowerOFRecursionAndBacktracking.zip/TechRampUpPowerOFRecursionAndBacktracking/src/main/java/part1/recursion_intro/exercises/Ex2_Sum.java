package part1.recursion_intro.exercises;

public class Ex2_Sum {

	public static void main(String[] args) {
		System.out.println(sum(new int[] {1, 2, 3, 7, 8, 9 }));
		System.out.println(sum(new int[] {1, 2, 3, 4, 3, 2, 1} ));
	}

	static int sum(final int[] values) {
		// TODO
		return 0;
	}
}
