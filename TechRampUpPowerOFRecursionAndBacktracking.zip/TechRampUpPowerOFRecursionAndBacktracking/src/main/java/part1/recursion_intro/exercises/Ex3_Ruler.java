package part1.recursion_intro.exercises;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex3_Ruler
{
    private Ex3_Ruler()
    {
    }

    public static void drawRuler(final int majorTickCount, final int maxLength)
    {
        // TODO
    }

    public static void main(String[] args)
    {
        drawRuler(3, 4);
    }
}