package part1.recursion_intro.exercises;

public class Ex4_Palindrome {

	public static void main(String[] args) {
		System.out.println(isPalindromeRec("ABCBA"));
		System.out.println(isPalindromeRec("ABCba"));
		System.out.println(isPalindromeRec("Michael"));

	}

	public static boolean isPalindromeRec(final String input) {
		// TODO
		return false;
	}
}
