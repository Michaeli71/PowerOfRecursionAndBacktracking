package part1.recursion_intro.solutions;

import java.util.List;

public class Ex2_Sum {

	public static void main(String[] args) {
		System.out.println(sum(new int[] {1, 2, 3, 7, 8, 9 }));
		System.out.println(sum(new int[] {1, 2, 3, 4, 3, 2, 1} ));
		System.out.println(sum(List.of(1, 2, 3, 4)));
		System.out.println(sum(List.of(1, 2, 3, 4, 5)));
	}

	static int sum(final int[] values) {
		return sum(values, 0);
	}

	static int sum(final int[] values, final int pos) {
		// rekursiver Abbruch
		if (pos >= values.length)
			return 0;
		
		int value = values[pos];
		// rekursiver Abstieg
		return value + sum(values, pos + 1);
	}
	
	static int sum(final List<Integer> values) {
		if (values.size() == 0)
			return 0;

		if (values.size() == 1)
			return values.get(0);
		else
		{
			int sumTail = sum(values.subList(1,  values.size()));
			return values.get(0) + sumTail;
		}
	}
}
