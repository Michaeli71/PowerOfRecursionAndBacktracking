package part1.recursion_intro.solutions;

public class Ex1_GCD {

	public static void main(String[] args) {
		System.out.println(gcd(42, 6));
		System.out.println(gcd(42, 7));
		System.out.println(gcd(42, 21));
	}

	static int gcd(final int a, final int b) {
		// rekursiver Abbruch 
		if (b == 0)
			return a;
		
		// rekursiver Abstieg
		return gcd(b, a % b);
	}
}
