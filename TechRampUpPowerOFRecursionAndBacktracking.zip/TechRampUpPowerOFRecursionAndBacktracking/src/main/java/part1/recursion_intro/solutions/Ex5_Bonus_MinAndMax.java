package part1.recursion_intro.solutions;

import java.util.List;

public class Ex5_Bonus_MinAndMax {

	public static void main(String[] args) {

		System.out.println(calcMinAndMax(List.of(2, 3, 5, 7, 11, 1, 2, 13)));
		System.out.println(calcMinAndMax(List.of(23, 11, 7, 2, 14, 7)));
		System.out.println(calcMinAndMax(List.of(71, 79, 20)));
	}

	record MinAndMaxValue(int min, int max) {
	}

	static MinAndMaxValue calcMinAndMax(List<Integer> values) {
		if (values.size() == 0)
			throw new IllegalStateException("empty input");

		if (values.size() == 1)
			return new MinAndMaxValue(values.get(0), values.get(0));
		else if (values.size() == 2) {
			if (values.get(0) < values.get(1))
				return new MinAndMaxValue(values.get(0), values.get(1));
			else
				return new MinAndMaxValue(values.get(1), values.get(0));
		} else {
			// teile in 2 Hälften
			int half = values.size() / 2;
			MinAndMaxValue minMaxLower = calcMinAndMax(values.subList(0, half));
			MinAndMaxValue minMaxUpper = calcMinAndMax(values.subList(half, values.size()));

			return new MinAndMaxValue(Math.min(minMaxLower.min, minMaxUpper.min),
					Math.max(minMaxLower.max, minMaxUpper.max));
		}
	}
}
