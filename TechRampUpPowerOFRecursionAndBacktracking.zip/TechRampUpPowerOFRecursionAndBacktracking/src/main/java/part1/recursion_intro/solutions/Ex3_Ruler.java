package part1.recursion_intro.solutions;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex3_Ruler
{
    private Ex3_Ruler()
    {
    }

    public static void drawRuler(final int majorTickCount, final int maxLength)
    {
        drawLine(maxLength, "0");

        for (int i = 1; i < majorTickCount; i++)
        {
            drawInterval(maxLength - 1);
            drawLine(maxLength, "" + i);
        }
    }

    public static void drawInterval(final int centerLength)
    {
        if (centerLength > 0)
        {
            drawInterval(centerLength - 1);
            drawLine(centerLength, "");
            drawInterval(centerLength - 1);
        }
    }

    private static void drawLine(int count, final String label)
    {
        System.out.println("-".repeat(count) + " " + label);
    }

    public static void main(String[] args)
    {
        drawRuler(3, 4);
    }
}